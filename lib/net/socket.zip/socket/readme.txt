Java / C++ Socket Classes
---------------------------------

This is a set of C++ and Java classes that allow socket
communication between the languages.  

On linux, to build type "make".  For Windows, a Visual
Studio 2008 solution is provided.

Currently the datagram methods are broken/not implemented.

You can use this code for whatever you like.

For more information, see:
http://www.keithv.com/software/socket

Revision history:
----------------
11/98 - Original release
10/09 - Updated to work with modern compilers

Have fun!
Keith Vertanen


